
const Project = require('../models/projectModel');

// Controller methods for Project
const createProject = async (req, res) => {
  try {
    const { name, description ,progress} = req.body;
    const project = await Project.create({ name, description,progress });

    res.status(201).json(project);
  } catch (error) {
    res.status(500).json({ error: 'Error creating project' });
  }
};

const getAllProjects = async (req, res) => {
  try {
    const projects = await Project.find();

    res.status(200).json(projects);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching projects' });
  }
};

const getProjectById = async (req, res) => {
  try {
    const { projectId } = req.params;
    const project = await Project.findById(projectId);

    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    res.status(200).json(project);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching project' });
  }
};

// Add more controller methods for updating, deleting projects, etc. as needed

module.exports = {
  createProject,
  getAllProjects,
  getProjectById,
  // Add other controller methods
};
